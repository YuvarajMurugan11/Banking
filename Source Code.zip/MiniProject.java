package project;

import java.util.*;

//Base Account Class
abstract class Account {
 private String accountHolderName;
 private String contact;
 private String type;
 protected double balance;

 public Account(String accountHolderName, String contact, String type, double initialBalance) {
     this.accountHolderName = accountHolderName;
     this.contact = contact;
     this.type = type;
     this.balance = initialBalance;
 }

 public abstract void deposit(double amount);

 public abstract void withdraw(double amount);

 public double checkBalance() {
     return balance;
 }

 public String getAccountHolderName() {
     return accountHolderName;
 }

 public String getType() {
     return type;
 }
}

//Savings Account Class
class SavingAccount extends Account {

 public SavingAccount(String accountHolderName, String contact, double initialBalance) {
     super(accountHolderName, contact, "Saving", initialBalance);
 }

 @Override
 public void deposit(double amount) {
     balance += amount;
     System.out.println("Deposited: " + amount);
 }

 @Override
 public void withdraw(double amount) {
     if (balance >= amount) {
         balance -= amount;
         System.out.println("Withdrawn: " + amount);
     } else {
         System.out.println("Insufficient balance.");
     }
 }
}

//Current Account Class
class CurrentAccount extends Account {

 public CurrentAccount(String accountHolderName, String contact, double initialBalance) {
     super(accountHolderName, contact, "Current", initialBalance);
 }

 @Override
 public void deposit(double amount) {
     balance += amount;
     System.out.println("Deposited: " + amount);
 }

 @Override
 public void withdraw(double amount) {
     if (balance >= amount) {
         balance -= amount;
         System.out.println("Withdrawn: " + amount);
     } else {
         System.out.println("Insufficient balance.");
     }
 }
}

//Bank Class
class Bank {
 private String ifsc;
 private String name;
 private List<Account> accounts;

 public Bank(String ifsc, String name) {
     this.ifsc = ifsc;
     this.name = name;
     this.accounts = new ArrayList<>();
 }

 public void createAccount(String accountType, String accountHolderName, String contact, double initialBalance) {
     Account account;
     if ("Saving".equalsIgnoreCase(accountType)) {
         account = new SavingAccount(accountHolderName, contact, initialBalance);
     } else if ("Current".equalsIgnoreCase(accountType)) {
         account = new CurrentAccount(accountHolderName, contact, initialBalance);
     } else {
         System.out.println("Invalid account type.");
         return;
     }
     accounts.add(account);
     System.out.println("Account created successfully.");
 }

 public void searchAccount(String accountHolderName) {
     for (Account account : accounts) {
         if (account.getAccountHolderName().equalsIgnoreCase(accountHolderName)) {
             System.out.println("Account found: " + account.getAccountHolderName() + ", Type: " + account.getType() + ", Balance: " + account.checkBalance());
             return;
         }
     }
     System.out.println("Account not found.");
 }

 public void displayTotalAccounts() {
     System.out.println("Total accounts: " + accounts.size());
 }

 public void displayVipAccounts(double threshold) {
     System.out.println("VIP Accounts (Balance > " + threshold + "): ");
     for (Account account : accounts) {
         if (account.checkBalance() > threshold) {
             System.out.println(account.getAccountHolderName() + ", Balance: " + account.checkBalance());
         }
     }
 }

 public Account getAccount(String accountHolderName) {
     for (Account account : accounts) {
         if (account.getAccountHolderName().equalsIgnoreCase(accountHolderName)) {
             return account;
         }
     }
     return null;
 }
}

//Main Class with Menu
public class MiniProject {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
     Bank bank = new Bank("IFSC123", "MyBank");

     while (true) {
         System.out.println("\n1. Create Account\n2. Search Account\n3. Display Total Accounts\n4. VIP Accounts\n5. Access an Account\n6. Exit");
         System.out.print("Enter your choice: ");
         int choice = scanner.nextInt();
         scanner.nextLine(); // Consume newline

         switch (choice) {
             case 1:
                 System.out.print("Enter account type (Saving/Current): ");
                 String type = scanner.nextLine();
                 System.out.print("Enter account holder name: ");
                 String name = scanner.nextLine();
                 System.out.print("Enter contact: ");
                 String contact = scanner.nextLine();
                 System.out.print("Enter initial balance: ");
                 double balance = scanner.nextDouble();
                 bank.createAccount(type, name, contact, balance);
                 break;
             case 2:
                 System.out.print("Enter account holder name to search: ");
                 String searchName = scanner.nextLine();
                 bank.searchAccount(searchName);
                 break;
             case 3:
                 bank.displayTotalAccounts();
                 break;
             case 4:
                 System.out.print("Enter VIP threshold: ");
                 double threshold = scanner.nextDouble();
                 bank.displayVipAccounts(threshold);
                 break;
             case 5:
                 System.out.print("Enter account holder name to access: ");
                 String accessName = scanner.nextLine();
                 Account account = bank.getAccount(accessName);
                 if (account != null) {
                     while (true) {
                         System.out.println("\n1. Deposit\n2. Withdraw\n3. Check Balance\n4. Exit");
                         System.out.print("Enter your choice: ");
                         int subChoice = scanner.nextInt();
                         if (subChoice == 4) break;
                         switch (subChoice) {
                             case 1:
                                 System.out.print("Enter amount to deposit: ");
                                 double depositAmount = scanner.nextDouble();
                                 account.deposit(depositAmount);
                                 break;
                             case 2:
                                 System.out.print("Enter amount to withdraw: ");
                                 double withdrawAmount = scanner.nextDouble();
                                 account.withdraw(withdrawAmount);
                                 break;
                             case 3:
                                 System.out.println("Balance: " + account.checkBalance());
                                 break;
                             default:
                                 System.out.println("Invalid choice.");
                         }
                     }
                 } else {
                     System.out.println("Account not found.");
                 }
                 break;
             case 6:
                 System.out.println("Exiting...");
                 scanner.close();
                 return;
             default:
                 System.out.println("Invalid choice.");
         }
     }
 }
}
